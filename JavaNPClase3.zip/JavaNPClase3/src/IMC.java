import java.text.DecimalFormat;
import java.util.Scanner;

public class IMC {

	public static void main(String[] args) {
		// Calculo de IMC Indice de Masca Corporal
		
		/*
		   ¿Cómo se calcula el índice de masa corporal y un ejemplo?
			Fórmula usando el sistema métrico, común en países de habla hispana
			El IMC es su peso en kilos divido por la altura (estatura) al cuadrado.
			IMC = Peso (kg) / altura (m)2
			Altura: 165 cm (1,65 m).
			Peso: 68 kg.
			Cálculo: 68 ÷ 1,652 (2,7225) = 24,98.
			
			
			//https://tn.com.ar/sociedad/2021/02/08/imc-que-es-y-como-se-calcula/
			
			IMC <15, 					"delgadez muy severa"
			IMC entre 15 a 15.9 		"delgadez severa"
			IMC entre 16 a 18.4 		"es delgadez" 
			IMC entre 18,5 y 24,9 		"peso normal"
			IMC entre 25 y 29.9 		"sobrepeso"
			IMC entre 30 a 34.9 		"obesidad moderada"
			IMC entre 35 a 39.9 		"obesidad severa"
			IMC >40 					"obesidad mórbida"
			
			
		 */

		//Colores ANSI
		String negro = "\u001B[30m";
		String rojo = "\u001B[31m";
		String verde = "\u001B[32m";
		String amarillo = "\u001B[33m";
		String azul = "\u001B[34m";
		String purpura = "\u001B[35m";
		String cyan = "\u001B[36m";
		String blanco = "\u001B[37m";
		String reset = "\u001B[0m";
		
		
		//cartel de bienvenida
		System.out.println(verde);
		System.out.println("********************************************");
		System.out.println("* Calcular Indice de Masa Corporal Humana  *");
		System.out.println("********************************************");
		System.out.println(cyan);
		
		//Ingreso de datos de entrada
		System.out.print("Ingrese su peso en Kilogramos: ");
		int peso=new Scanner(System.in).nextInt();
		
		System.out.print("Ingrese su altura en centimetros: ");
		int alturaCms=new Scanner(System.in).nextInt();
		
		//Conversión de centímetros a metros
		double alturaMtros=(double)alturaCms/100;
		
		//Calculo del IMC
		final double IMC = peso / Math.pow(alturaMtros, 2);
		
		//Calculo de estado
		String estado="";
		if(IMC<15) 					estado="delgadez muy severa";
		if(IMC>=15 && IMC<16) 		estado="delgadez severa";
		if(IMC>=16 && IMC<=18.5)	estado="delgadez";
		if(IMC>=18.5 && IMC<25)		estado="peso normal";
		if(IMC>=25 && IMC<30)		estado="sobrepeso";
		if(IMC>=30 && IMC<35)		estado="obesidad moderada";
		if(IMC>=35 && IMC<40) 		estado="obesidad severa";
		if(IMC>40) 					estado="obesidad morbida";
		
		//Impresión de resultados
		DecimalFormat df=new DecimalFormat("###.00");
		System.out.println("El índice de masa corporal es "+df.format(IMC));
		System.out.println("Su estado es "+estado);
		
	}

}
