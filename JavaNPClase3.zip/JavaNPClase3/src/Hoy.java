import java.time.LocalDate;
import java.util.Calendar;

public class Hoy {
	public static void main(String[] args) {
		//Colores ANSI
		String negro = "\u001B[30m";
		String rojo = "\u001B[31m";
		String verde = "\u001B[32m";
		String amarillo = "\u001B[33m";
		String azul = "\u001B[34m";
		String purpura = "\u001B[35m";
		String cyan = "\u001B[36m";
		String blanco = "\u001B[37m";
		String reset = "\u001B[0m";
		
		Calendar cal=Calendar.getInstance();
		String ubicacion=cal
								.getTimeZone()
								.getID()
								.replaceAll("/", ", ")
								.replaceAll("_"," ");
		
		LocalDate ld=LocalDate.now();
		int numeroDiaSemana=ld.getDayOfWeek().getValue();
		int numeroDiaMes=ld.getDayOfMonth();
		int numeroMes=ld.getMonthValue();
		int anio=ld.getYear();
		
		String nombreDiaSemana="";
//		if(numeroDiaSemana==1) nombreDiaSemana="Lunes";
//		if(numeroDiaSemana==2) nombreDiaSemana="Martes";
//		if(numeroDiaSemana==3) nombreDiaSemana="Miércoles";
//		if(numeroDiaSemana==4) nombreDiaSemana="Jueves";
//		if(numeroDiaSemana==5) nombreDiaSemana="Viernes";
//		if(numeroDiaSemana==6) nombreDiaSemana="Sábado";
//		if(numeroDiaSemana==7) nombreDiaSemana="Domingo";
		
		switch(numeroDiaSemana) {
			case 1: nombreDiaSemana="Lunes"; 		break;
			case 2: nombreDiaSemana="Martes"; 		break;
			case 3: nombreDiaSemana="Miércoles"; 	break;
			case 4: nombreDiaSemana="Jueves"; 		break;
			case 5: nombreDiaSemana="Viernes"; 		break;
			case 6: nombreDiaSemana="Sábado"; 		break;
			case 7: nombreDiaSemana="Domingo"; 		break;
		}
		
		String nombreMes="";
//		if(numeroMes==1) 	nombreMes="Enero";
//		if(numeroMes==2) 	nombreMes="Febrero";
//		if(numeroMes==3) 	nombreMes="Marzo";
//		if(numeroMes==4) 	nombreMes="Abril";
//		if(numeroMes==5) 	nombreMes="Mayo";
//		if(numeroMes==6) 	nombreMes="Junio";
//		if(numeroMes==7) 	nombreMes="Julio";
//		if(numeroMes==8) 	nombreMes="Agosto";
//		if(numeroMes==9) 	nombreMes="Septiembre";
//		if(numeroMes==10) 	nombreMes="Octubre";
//		if(numeroMes==11) 	nombreMes="Noviembre";
//		if(numeroMes==12) 	nombreMes="Marzo";
		
		switch(numeroMes) {
			case 1 :	nombreMes="Enero"; 			break;
			case 2 :	nombreMes="Febrero"; 		break;
			case 3 :	nombreMes="Marzo"; 			break;
			case 4 :	nombreMes="Abril"; 			break;
			case 5 :	nombreMes="Mayo"; 			break;
			case 6 :	nombreMes="Junio"; 			break;
			case 7 :	nombreMes="Julio"; 			break;
			case 8 :	nombreMes="Agosto"; 		break;
			case 9 :	nombreMes="Septiembre"; 	break;
			case 10:	nombreMes="Octubre"; 		break;
			case 11:	nombreMes="Noviembre"; 		break;
			case 12:	nombreMes="Diciembre"; 		break;
		}
		
		System.out.print(verde);
		System.out.println("Hoy es "+nombreDiaSemana+" "+numeroDiaMes+" de "+nombreMes+" de "+anio);
		System.out.println(ubicacion);
		System.out.println(reset);
	}
}
