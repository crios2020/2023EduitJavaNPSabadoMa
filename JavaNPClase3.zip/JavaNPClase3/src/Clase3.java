
public class Clase3 { // start clase principal

	public static void main(String[] args) { // start método main
		// Clase 3

		int nro = 4;
		boolean bool = true;

		// Estructura condidional if
		if (bool) {
			System.out.println("verdad 1");
		}

		// Uso de llaves recomendado por Java
		if (nro == 4) {
			// código esta indentado
			System.out.println("verdad 2");
		}

		// Uso de llaves abreviado
		if (bool) System.out.println("verdad 3");

		// Uso de llaves expandido
		if (bool) 
		{
			System.out.println("verdad 4");
		}

		// Estructura if - else
		if (!bool) {
			System.out.println("verdad 5");
		} else {
			System.out.println("falso 5");
		}
	
		// Uso de llaves abreviado
		if(!bool) 	System.out.println("verdad 6");
		else		System.out.println("falso 6");

		// Uso de llaves expandido
		if(bool)
		{
			System.out.println("verdad 7");
		}
		else
		{
			System.out.println("false 7");
		}
		
		
		Hoy.main(null);
		
		//Circulo.main(null);
		
		//Estructura switch
		nro=25;
		switch(nro) {
			case 1: System.out.println("valor 1");  break;
			case 2: System.out.println("valor 2");  break;
			case 3: System.out.println("valor 3");  break;
			case 4: System.out.println("valor 4");  break;
			case 5: System.out.println("valor 5");
			case 6: System.out.println("valor 6");
			case 7: System.out.println("valor 7");
			case 8: System.out.println("valor 8");  break;
			case 9: case 10: case 11: case 12:
					System.out.println("valor entre 9 y 12"); break;
			default: System.out.println("El valor es otro");
		}
		
		//Estructura While
		int a=1;
		System.out.println("-- Inicio de estructura while --");
		while(a<=10) {
			System.out.println(a);
			a++;
		}
		System.out.println("-- Fin de estructura while --");
		System.out.println(a);		// 11
		
		//Uso de llaves expandido
		a=1;
		while(a<=10)
		{
			System.out.println(a);
			a++;
		}
		
		//Uso de llaves abreviado
		a=1;
		while(a<=10) System.out.println(a++);
		
//		//loop infinito
//		a=1;
//		while(true) {
//			System.out.println(a);
//			a++;
//		}
		
		//loop infinito
//		a=1;
//		while(a<=10 || true) {
//			System.out.println(a);
//			a++;
//		}
		
		//loop infinito
//		a=1;
//		while(a<=10 || a>=1) {
//			System.out.println(a);
//			a++;
//		}
		
		//loop infinito
//		a=1;
//		while(a<=10) {
//			System.out.println(a--);
//			a++;
//		}
		
		//loop infinito
//		a=1;
//		while(a<=10);
//		{
//			System.out.println(a);
//			a++;
//		}
		
		//Estructura While
		a=20;
		System.out.println("-- Inicio de estructura while --");
		while(a<=10) {
			System.out.println(a);
			a++;
		}
		System.out.println("-- Fin de estructura while --");
		System.out.println(a);	
		
		//Estructura Do While
		a=20;
		System.out.println("-- Inicio de estructura do while --");
		do {
			System.out.println(a);
			a++;
		}while(a<=10);
		System.out.println("-- Fin de estructura do while --");
		System.out.println(a);
		
		
		//System.out.println("Fin del programa!");
	}// end método main
	
	// no escribir código aquí

}// end clase principal
