import java.util.Scanner;

public class Login {

	public static void main(String[] args) {
		//Colores ANSI
		String negro = "\u001B[30m";
		String rojo = "\u001B[31m";
		String verde = "\u001B[32m";
		String amarillo = "\u001B[33m";
		String azul = "\u001B[34m";
		String purpura = "\u001B[35m";
		String cyan = "\u001B[36m";
		String blanco = "\u001B[37m";
		String reset = "\u001B[0m";
		
		/*
		 * Igresar por consola el nombre de usuario y la clave
		 * 
		 * - si el usuario es root y la clave es 123 informar "Bienvenido al sistema!"
		 * - si el usuario es root y la clase no es 123 informar "Clave incorrecta!"
		 * - si el usuario no es root informar "Usuario incorrecto"
		 * 
		 */

		//cartel de bienvenida
		System.out.println(verde);
		System.out.println("**************************************************");
		System.out.println("*             LOGIN DEL SISTEMA                  *");
		System.out.println("**************************************************");
		System.out.println(cyan);
		
		//Ingreso de datos
		System.out.println(cyan);
		System.out.print("Ingrese su username: ");
		String user=new Scanner(System.in).nextLine();
		System.out.print("Ingrese su password: ");
		String pass=new Scanner(System.in).nextLine();
		
		//System.out.println(user+", "+pass);
		//System.out.println(user=="root");
		//System.out.println(user.equals("root"));
		
		//Verificación de datos de entrada
//		if (user.equals("root")) {
//			if (pass.equals("123")) {
//				System.out.println(verde + "Bienvenido al sistema!");
//			} else {
//				System.out.println(rojo + "Clave incorrecta!");
//			}
//		} else {
//			System.out.println(rojo + "Usuario incorrecto!");
//		}
		
		if(user.equals("root") && pass.equals("123")) {
			System.out.println(verde + "Bienvenido al sistema!");
			Welcome.main(null);
			Hoy.main(null);
		}
		if(user.equals("root") && !pass.equals("123"))	System.out.println(rojo + "Clave incorrecta!");
		if(!user.equals("root"))						System.out.println(rojo + "Usuario incorrecto!");
		
		System.out.println(reset);
	}

}
