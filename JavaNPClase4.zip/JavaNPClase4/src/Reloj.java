import java.text.DecimalFormat;
import java.time.LocalTime;

public class Reloj {
	public static void main(String[] args) {
		//Colores ANSI
		String negro = "\u001B[30m";
		String rojo = "\u001B[31m";
		String verde = "\u001B[32m";
		String amarillo = "\u001B[33m";
		String azul = "\u001B[34m";
		String purpura = "\u001B[35m";
		String cyan = "\u001B[36m";
		String blanco = "\u001B[37m";
		String reset = "\u001B[0m";
		DecimalFormat df=new DecimalFormat("00");
		while(true) {
			LocalTime lt=LocalTime.now();
			System.out.println(verde+df.format(lt.getHour())+":"+df.format(lt.getMinute())+":"+df.format(lt.getSecond()));
			try {Thread.sleep(1000);} catch(Exception e) {}  	//Detiene el programa por 1s
		}
	}
}
