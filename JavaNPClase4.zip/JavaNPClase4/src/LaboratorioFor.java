
public class LaboratorioFor {

	public static void main(String[] args) {
		
//		Ejercicio 1
//		Imprimir los números del 1 al 10 uno abajo del otro.
		System.out.println("Ejercicio 1: ");
		for(int a=1; a<=10; a++) {
			System.out.println(a);
		}

		
//		Ejercicio 2
//		Imprimir los números del 1 al 10 salteando de a dos uno abajo del otro.
		System.out.println("Ejercicio 2: ");
		for(int a=1; a<=10; a+=2) {
			System.out.println(a);
		}
		
			
//		Ejercicio 3
//		Imprimir los números del 10 al 1 uno abajo del otro.
		System.out.println("Ejercicio 3: ");
		for(int a=10; a>=1; a--) {
			System.out.println(a);
		}
		
//		Ejercicio 4
//		Imprimir la suma de los números impares del 1 al 10.
		System.out.println("Ejercicio 4: ");
		int suma=0;			//acumulador
//		for(int a=1; a<=10; a+=2) {
//			suma+=a;
//		}
		for(int a=1; a<=10; a++) {
			if(a%2!=0) suma+=a;
		}
		System.out.println("Suma: "+suma);
	
		//Operador Resto %
		System.out.println(15%2); 				// 1
		System.out.println(14%2); 				// 0
		System.out.println(-14%2); 				// 0
		System.out.println(-15%2); 				//-1
		System.out.println(17%3); 				// 2
		
//		Ejercicio 5
//		Mostrar la suma de 
//		la multiplicación de los números del 1 al 5 
//		con 
//		la suma de los números del 1 al 5.
		System.out.println("Ejercicio 5: ");
		suma=0;
		int multi=1;
		for(int a=1; a<=5; a++) {
			multi*=a;
			suma+=a;
		}
		System.out.println("Total: "+(multi+suma));
		
		
//		Ejercicio 6
//		Imprimir la siguiente figura utilizando la estructura for:
//		@
//		@
//		@
//		@
		
		System.out.println("Ejercicio 6: ");
//		System.out.println("@");
//		System.out.println("@");
//		System.out.println("@");
//		System.out.println("@");
		for(int a=1; a<=4; a++) {
			System.out.println("@");
		}
		
//		Bonus
//		@@@@@
		for(int a=1; a<=5; a++) {
			System.out.print("@");
		}
		System.out.println();
		
//		Ejercicio 7
//		Imprimir la siguiente figura utilizando la estructura for:
//		@
//		@@
//		@
//		@@
//		@
		System.out.println("Ejercicio 7: ");
		for(int a=1; a<=5; a++) {
			if(a%2==0) 	System.out.println("@@");
			else 		System.out.println("@");
		}
		
//		Bonus
//		@@@@@
//		@@@@@
//		@@@@@
//		@@@@@
//		@@@@@
		for(int x=1; x<=5; x++) {
			for(int a=1; a<=5; a++) {
				System.out.print("@");
			}
			System.out.println();
		}
		
			
//		Ejercicio 8
//		Imprimir la siguiente figura utilizando la estructura for:
//		@
//		@@
//		@@@
//		@@@@
//		@@@@@
		System.out.println("Ejercicio 8");
		for(int x=1; x<=5; x++) {
			for(int a=1; a<=x; a++) {
				System.out.print("@");
			}
			System.out.println();
		}
		

//		Ejercicio 9
//		Imprimir la siguiente figura utilizando la estructura for:
//		@@@@@
//		@@@@
//		@@@
//		@@
//		@
//
//		Ejercicio 10
//		Imprimir la siguiente figura utilizando la estructura for:
//		@
//		@@
//		@@@
//		@@@@
//		@@@
//		@@
//		@
//
//		Ejercicio 11
//		Imprimir la siguiente figura utilizando la estructura for:
//		@@@@@
//		@@@
//		@
//		@@@
//		@@@@@


	}

}
