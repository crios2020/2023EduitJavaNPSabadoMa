import java.util.Scanner;

public class Laboratorio1 {

	public static void main(String[] args) {
		/*
	 	Ejercicio 1
			Crear un programa que ingrese una oración y
			muestre cuál es el carácter que más se repite.
			Consideraciones
			● No debe incluir el espacio en blanco.
			● La oración a ingresar no debe estar vacía.
		 */
		

		
		
		//Entrada de datos
		System.out.println("Ingrese una oración: ");
		String oracion=new Scanner(System.in).nextLine();
		oracion=oracion.replace(" ", "");
		//System.out.println(oracion);

		// String texto="hola";
		// texto.charAt(0);		//h
		// texto.charAt(1);		//o
		// texto.charAt(2);		//l
		// texto.charAt(3);		//a
		// texto.charAt(4);		//error
		// for(int a=0; a<texto.length(); a++){
		//		System.out.println(texto.charAt(a));
		// }
		
		if(oracion.isEmpty()) {
			System.out.println("La oración esta vacía!");
		}else {
			char caracterMasRepetido=oracion.charAt(0);
			int cantidadRepeticiones = 0;
			for(int l=0;l<oracion.length();l++) {
				char ch=oracion.charAt(l);
				//System.out.println(ch);
				int contAux=0;
				
				for(int i=0; i<oracion.length(); i++) {
					if(ch==oracion.charAt(i)) {
						contAux++;
					}
				}
				
				if(contAux>cantidadRepeticiones) {
					cantidadRepeticiones=contAux;
					caracterMasRepetido=ch;
				}
			}
			System.out.println("El carácter más repetido es: "+caracterMasRepetido);
			System.out.println("Se encuentra "+cantidadRepeticiones+" veces.");
			
		}

	}

}
