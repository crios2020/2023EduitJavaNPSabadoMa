import java.text.DecimalFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Iterator;

public class Clase4 {

	public static void main(String[] args) {
		// Clase 4
		
		LocalDateTime horaInicial=LocalDateTime.now();
		
		//Estructura While
		int b=1;
		System.out.println("-- Inicio Estructura While --");
		while(b<=10) {
			System.out.println(b);
			b++;
		}
		System.out.println("-- Fin Estructura While --");
		System.out.println(b);
		
		
		//Estructura For
		System.out.println("-- Inicio Estructura For --");
		for(int a=1; a<=10; a++) {
			System.out.println(a);
		}
		System.out.println("-- Fin Estructura For --");
		//System.out.println(a);
		
		//Uso de llaves expandido
		for(int a=1; a<=10; a++) 
		{
			System.out.println(a);
		}
		
		//Uso de llaves abreviado
		for(int a=1; a<=10; a++) 	System.out.println(a);

		//Recorrido con variable global
		System.out.println("**********************************");
		for(b=1; b<=10; b++) {
			System.out.println(b);
		}
		System.out.println("**********************************");
		System.out.println(b);
		System.out.println("**********************************");
		for(b++; b<=20; b++) {
			System.out.println(b);
		}
		System.out.println("**********************************");
		for(;b<=30;b++) {
			System.out.println(b);
		}
		
		//Recorrido con multiples variables de control
		System.out.println("**********************************");
		for(int r=1, s=1; r<=5 && s<=10; r++, s++) {
			System.out.println(r+" "+s);
		}
		
		System.out.println("**********************************");
		for(int r=1, s=1; r<=5 || s<=10; r++, s++) {
			System.out.println(r+" "+s);
		}
		
		
		//For anidado
		int cont=1;
		for(int x=1;x<=10;x++) {
			for(int r=1; r<=10; r++) {
				for(int s=1; s<=10; s++) {
					System.out.println(x+" "+r+" "+s+" "+cont);
					cont++;
				}
			}
		}
		
		//Horas del día
		
		DecimalFormat df=new DecimalFormat("00");
		
//		for(int hora=0; hora<24; hora++) {
//			for(int minuto=0; minuto<60; minuto++) {
//				for(int segundo=0; segundo<60; segundo++) {
//					System.out.println(df.format(hora)+":"+df.format(minuto)+":"+df.format(segundo));
//					try {Thread.sleep(1000);} catch(Exception e) {}  	//Detiene el programa por 1s
//				}
//			}
//		}
		
		LocalDateTime horaFinal=LocalDateTime.now();
		System.out.println(horaInicial);
		System.out.println(horaFinal);
		Duration duration=Duration.between(horaInicial, horaFinal);
		System.out.println("Duración: "+duration.toMillis());
		
		
		//Sentencias break y continue
		//loop infinito
		for(int a=1;;a++) {
			if(a==10) continue;
			System.out.println(a);
			if(a==20) break;
			
		}
		
		
		//loop infinito
//		for(;;) {
//			System.out.println("x");
//		}
		
		//loop infinito
//		for(int a=1;;a++) {
//			System.out.println(a);
//		}
		
		//loop infinito
//		for(int a=1;true;a++) {
//			System.out.println(a);
//		}
		
		//loop infinito
//		for(int a=1;a<=10 || true;a++) {
//			System.out.println(a);
//		}
		
		
		//loop infinito
//		for(int a=1;a<=10 || a>=1;a++) {
//			System.out.println(a);
//		}
		
		
		//loop infinito
//		for(int a=1;a<=10;) {
//			System.out.println(a);
//		}
		
		//loop infinito
//		for(int a=1;a<=10;a++) {
//			System.out.println(a--);
//		}
		
		//loop infinito
//		b=2;
//		for(int a=b;b<=10;a++) {
//			System.out.println(a);
//		}
		
		//loop infinito
//		b=2;
//		for(int a=b;a<=10;b++) {
//			System.out.println(a);
//		}
		
		
		/*
		 	Ejercicio 1
				Crear un programa que ingrese una oración y
				muestre cuál es el carácter que más se repite.
				Consideraciones
				● No debe incluir el espacio en blanco.
				● La oración a ingresar no debe estar vacía.
		 */
		
		
		
	}

}
