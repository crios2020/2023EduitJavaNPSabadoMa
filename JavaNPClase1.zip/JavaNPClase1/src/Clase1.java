
public class Clase1 {

	public static void main(String[] args) {
		
		/*
		 * Curso: 		Java No Programadores			
		 * Duración:	18 hs
		 * Días:		Sábados		10:00 a 13:00 hs  
		 * Profe:		Carlos Rios		carlos.rios@educacionit.com
		 * 
		 * Materiales:	alumni.educacionit.com
		 * 				user:	email
		 * 				pass:	dni
		 *
		 * Github:		https://github.com/crios2020/2023EduitJavaNPSabadoMa
		 * CodeShare:	https://codeshare.io/crios2020
		 * 
		 * Software:	Hay que instalar esto!!!!
		 * 				JDK		(Java Development Kit) (Kit de Desarrollo Java)
		 * 				https://www.oracle.com/ar/java/technologies/downloads/#jdk17-windows
		 * 
		 * 				IDE		(Integrated Development Enviroment) (Entorno de Desarrollo Integrado)
		 * 				Eclipse	https://www.eclipse.org/downloads/
		 * 
		 */
		
		//Linea de comentarios
		
		/* Bloque de comentarios */
		
		//Colores ANSI
		String negro = "\u001B[30m";
		String rojo = "\u001B[31m";
		String verde = "\u001B[32m";
		String amarillo = "\u001B[33m";
		String azul = "\u001B[34m";
		String purpura = "\u001B[35m";
		String cyan = "\u001B[36m";
		String blanco = "\u001B[37m";
		String reset = "\u001B[0m";
		
		System.out.println(rojo+"Hola Mundo!");		// Imprime en consola de sistema
		System.out.println(verde+"Hoy es Sábado!");
		
		// en eclipse syso ctrol space - atajo de teclado para  System.out.println();
		// ; es el terminador de sentencia
		// en eclipse F11 para ejecutar el programa
		
		System.out.println(azul+"Curso Java No Programadores!");
		System.out.print(blanco+"1");
		System.out.print("2");
		System.out.print("3");
		System.out.println("4");
		System.out.println(amarillo+"EducaciónIT");
		
		/*
		 * Hola Mundo!
		 * Hoy es Sábado!
		 * Curso Java No Programadores!
		 * 1234
		 * EducaciónIT
		 * 
		 */
		
		//Versión de Java
		System.out.println("Versión de Java: "+System.getProperty("java.version"));
		
		//Arte ASCII
		//https://fsymbols.com/es/arte-de-texto/
		
		// """ triple comilla para imprimir en muchas lineas """ se requiere JDK 16 o superior
		System.out.println(blanco+"""
				∵*.•´¸.•*´✶´♡
				° ☆ °˛*˛☆_Π______*˚☆*
				˚ ˛★˛•˚*/______/ ~⧹。˚˚
				˚ ˛•˛•˚ ｜ 田田 ｜門｜ ˚*
				🌷╬╬🌷╬╬🌷╬╬🌷╬╬🌷🌷╬╬🌷🌷╬╬🌷
				""");
		
		//Uso de Variables
		
		//Tipo de datos String, int, char, double, float, boolean
		
		//El identificador de variable (nombre de la variable) debe ir en minusculas
		//Puede tener varias letras y numeros, pero no puede inicar en un número
		
		//Tipo de datos int
		int a;					//Declaración de variable de tipo entero.
		a=2;					//Asignación de valor.
		
		int b=4;				//Declaración y asignación de valor.
		int c=a+b;				//6
		int d=65, e=29, f=39, g=38;	//Declaración y asignación multiple.
		
		//una variable solo puede ser declarada una vez
		//una variable puede tener infinitas asignaciones de valor
		
		//int a;	Error no se puede volver a declarar
		a=8;
		a=64;
		a=6;
		System.out.println(a);
		System.out.println(c);
		
		System.out.println("Variable a: "+a);
		System.out.println(2+2); 					//4
		System.out.println("2"+2); 					//22
		System.out.println("a+b="+a+b); 			//a+b=64
		System.out.println("a+b="+(a+b));			//a+b=10 
		
		int numero1=8;
		//int NUMERO1=8;
		//int 1numero=8;
		
		//Tipo de datos String
		String p="perro";
		String l="ladra";
		
		System.out.println(p+l); 					// perroladra
		System.out.println(p+" "+l); 				// perro ladra
		System.out.println(p+" que "+l); 			// perro que ladra
		System.out.println(rojo+p+" que "+l); 		// perro que ladra
		
		System.out.println(amarillo+"( ͡❛ ͜ʖ ͡❛)");
		System.out.println(reset);
		
		//Tipo de datos char (UNICODE)
		char car=65;
		System.out.println(car);
		car=937;
		System.out.println(car);
		
		//Tipo de datos boolean
		boolean bo=true;				// 1
		System.out.println(bo);
		bo=false;						// 0
		System.out.println(bo);
		
		//Tipo de datos float		32bits
		float fl=9.65f;
		System.out.println(fl);
		
		//Tipo de datos double		64bits
		double dl=9.65;
		System.out.println(dl);
		
		fl=10;
		dl=10;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		//Ingreso de datos por consola
		System.out.print(azul+"Ingrese su nombre: ");
		String nombre=new java.util.Scanner(System.in).nextLine();		//Ingresar datos de consola
		System.out.println(verde+"Hola "+nombre);
		
		
	}

}
