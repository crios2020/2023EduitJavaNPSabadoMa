
public class Clase2 {

	public static void main(String[] args) {
		// Java NP Clase 2 

		//Colores ANSI
		String negro = "\u001B[30m";
		String rojo = "\u001B[31m";
		String verde = "\u001B[32m";
		String amarillo = "\u001B[33m";
		String azul = "\u001B[34m";
		String purpura = "\u001B[35m";
		String cyan = "\u001B[36m";
		String blanco = "\u001B[37m";
		String reset = "\u001B[0m";
		
		//Operador de asignación =
		int nro1=5;
		int nro2=7;
		
		System.out.println(nro1);
		System.out.println(nro2);
		
		nro1=nro2;
		// <--
		
		System.out.println(nro1);
		System.out.println(nro2);
		
		//Operadores incrementales
		
		//sumar 1 a la variable			++
		nro1++;					//nro1=nro1+1;
		System.out.println(nro1);
		
		//restar 1 a la variable		--
		nro1--;					//nro1=nro1-1;
		System.out.println(nro1);
		
		//sumar 5 a la variable			+=
		nro1+=5;				//nro1=nro1+5;
		System.out.println(nro1);
		
		//restar 5 a la variable		-=
		nro1-=5;				//nro1=nro1-5;
		System.out.println(nro1);
		
		//multiplicar x5 la variable	*=
		nro1*=5;				//nro1=nro1*5;
		System.out.println(nro1);
		
		//Dividir /5 la variable		/=
		nro1/=5;				//nro1=nro1/5;
		System.out.println(nro1);
		
		//Uso de constantes
		//Utilidad Math
		
		//final double PI=3.14;
		final double PI=Math.PI;
		
		//PI++;	//Error no se puede cambiar el valor de una cte
		
		System.out.println(PI);
		
		//Operadores Logicos devuelven true false
		
		/*
		 * 	Operador	Nombre
		 * 	==			equals
		 *  !=			not equals
		 *  !			not
		 *  &&			and
		 *  ||			or
		 *  < <= >= >  comparación
		 * 
		 */
		
		/*
		 * 	Tabla de verdad
		 * 
		 * 		X	Y		OR		AND
		 * 		F	F		F		F
		 * 		F	V		V		F
		 * 		V	F		V		F
		 * 		V	V		V		V
		 * 
		 */
		
		System.out.println("-- Operadores Logicos --");
		System.out.println(nro1);			// 7
		System.out.println(nro2);			// 7
		
		boolean log1=true;
		boolean log2=false;
		
		boolean llueve=false;
		
		System.out.println(nro1==7); 			//true
		System.out.println(nro1==14); 			//false
		System.out.println(nro1+7==14);			//true
		System.out.println(nro1+nro2==14); 		//true
		System.out.println(nro1++==8);  		//false
		System.out.println(++nro2==8); 			//true
		
		System.out.println(nro1!=8); 			//false
		System.out.println(nro1!=9); 			//true
		
		System.out.println(nro1<15); 			//true
		System.out.println(nro1+nro2<=15); 		//false
		System.out.println(nro1<=8); 			//true
		System.out.println(nro1<=5); 			//false
		
		System.out.println(nro1>5); 			//true
		System.out.println(nro1>=8); 			//true
		
		System.out.println(log1); 				//true
		System.out.println(!log1); 				//false
		System.out.println(!!log1); 			//true
		System.out.println(!!!log1); 			//false
		System.out.println(!!!!log1); 			//true
		
		System.out.println(log1||log2); 		//true
		System.out.println(log1&&log2); 		//false
		
		System.out.println(!log1 || log2 || (!log1||!log2)); 		//true
		//					F	 o	 F	  o	 ( f   o   v )
		
		System.out.println(nro1+10<=30 && !(nro1-10>10-2) && (!llueve || !log2));  //true
		// 					      V     y          V       y (   V    o   V )
		
		
		//Precendencia y prodecedencia de operadores unarios ++ --
		System.out.println(nro1); 			// valor 8 		imprime 8
		System.out.println(nro1++); 		// valor 9 		imprime 8
		System.out.println(nro1); 			// valor 9 		imprime 9
		System.out.println(++nro1); 		// valor 10 	imprime 10
		
		//Operadores Binarios & | (& and binario	-	| or binario)
		System.out.println(log1 || log2); 			//true
		//					V   o
		
		System.out.println(log1 | log2); 			//true
		// 					V   o   F
		
		System.out.println(!!log1 || log2 || (!log1||!log2)); 		//true
		// 					  V   o
		
		System.out.println(!!log1 | log2 | (!log1|!log2)); 			//true
		// 					 V    o    F o     F  o    V
		
		System.out.println(log1 && log2);         					// false
		// 					V   y   F
		
		System.out.println(log1 & log2); 							// false
		// 					V   y   F
		
		
		System.out.println(log2 && log1); 							// false
		// 					F   y
				
		System.out.println(log2 & log1); 							// false
		// 					F   y   V
		
		System.out.println(nro1+10<=0 && !(nro1-10>10-2) && (!llueve || !log2));	//false
		// 					      F    Y
		
		System.out.println(nro1+10<=0 & !(nro1-10>10-2) & (!llueve || !log2));		//false
		// 						  F   Y          V      Y          V
		
		//Estructura condicional IF
		System.out.println("-- Estructura if --");
		llueve=false;
		boolean tenerDinero=false;
		
		if(llueve) {
			System.out.println("Usar Paragua!!!");
		}
		
//		if(llueve=true) {
//			System.out.println("Usar Paragua!!!");
//		}
		
		if(llueve==true) {			//No es eficiente
			System.out.println("Usar Paragua!!!");
		}
		
		if(!llueve) {
			System.out.println("Salimos al parque!!!");
		}
		
		if(tenerDinero) {
			System.out.println("Me voy a Europa!!");
		}
		
		//Estructura if else
		System.out.println("-- Estructura if - else --");
		llueve=false;
		tenerDinero=true;
		
		if(llueve) {
			System.out.println("Usar paraguas!!");
		} else {
			System.out.println("Salimos al parque!!");
		}
		
		if(tenerDinero) {
			System.out.println("Me voy de vacaciones a Europa!!");
		} else {
			System.out.println("Armamos la pileta de lona!");
		}
		
		//Para aprobar un credito, se requiere que el cliente tenga empleo, 
		// un sueldo mayor a 300mil pesos y una antiguedad laboral mayor a 5 años
		boolean empleo=true;
		int sueldoBasico=350000;
		int antiguedadLaboral=10;
		
		if(empleo && sueldoBasico>=300000 && antiguedadLaboral>=5) {
			System.out.println("Credito Aprobado!");
		}else {
			System.out.println("Credito No Aprobado!");
		}
		
		
	}

}