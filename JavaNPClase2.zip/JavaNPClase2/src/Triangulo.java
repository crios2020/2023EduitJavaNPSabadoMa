import java.util.Scanner;

public class Triangulo {
	public static void main(String[] args) {
		//Colores ANSI
		String negro = "\u001B[30m";
		String rojo = "\u001B[31m";
		String verde = "\u001B[32m";
		String amarillo = "\u001B[33m";
		String azul = "\u001B[34m";
		String purpura = "\u001B[35m";
		String cyan = "\u001B[36m";
		String blanco = "\u001B[37m";
		String reset = "\u001B[0m";
		
		
		//cartel de bienvenida
		System.out.println(verde);
		System.out.println("***************************************************************");
		System.out.println("* Calcular Superficie y Perímetro de un Triangulo Rectángulo  *");
		System.out.println("***************************************************************");
		System.out.println(cyan);
		
		//Ingreso de datos
		System.out.print("Ingrese la longitud de la base: ");
		int base=new Scanner(System.in).nextInt();
		System.out.print("Ingrese la longitud de la altura: ");
		int altura=new Scanner(System.in).nextInt();
		
		//Calculo de resultados
		int superficie=base*altura/2;
		int perimetro=base+altura+(int)Math.hypot(base, altura);
		
		//Impresión de resultados
		System.out.println("Superficie: "+superficie);
		System.out.println("Perímetro: "+perimetro);
		
		System.out.println(reset);
		
	}
}
