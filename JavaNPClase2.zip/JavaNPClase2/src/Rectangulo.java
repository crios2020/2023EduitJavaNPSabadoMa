import java.util.Scanner;

public class Rectangulo {
	public static void main(String[] args) {
		//Colores ANSI
		String negro = "\u001B[30m";
		String rojo = "\u001B[31m";
		String verde = "\u001B[32m";
		String amarillo = "\u001B[33m";
		String azul = "\u001B[34m";
		String purpura = "\u001B[35m";
		String cyan = "\u001B[36m";
		String blanco = "\u001B[37m";
		String reset = "\u001B[0m";
		
		
		//cartel de bienvenida
		System.out.println(verde);
		System.out.println("*****************************************************");
		System.out.println("* Calcular Superficie y Perímetro de un Rectángulo  *");
		System.out.println("*****************************************************");
		System.out.println(cyan);
		
		//Ingreso de datos
		System.out.print("Ingrese la longitud del lado 1: ");
		int lado1=new Scanner(System.in).nextInt();
		System.out.print("Ingrese la longitud del lado 2: ");
		int lado2=new Scanner(System.in).nextInt();
		
		//Calculo de resultados
		int superficie=lado1*lado2;
		int perimetro=(lado1+lado2)*2;
		
		//Impresión de resultados
		System.out.println("Superficie: "+superficie);
		System.out.println("Perímetro: "+perimetro);
		
		System.out.println(reset);
		
	}
}
